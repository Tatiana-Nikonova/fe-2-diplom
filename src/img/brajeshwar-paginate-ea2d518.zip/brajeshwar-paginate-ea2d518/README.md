# Simple Pagination with CSS3

- Read the [article](//brajeshwar.com/2011/pagination-css3-style/).
- [Demo](http://brajeshwar.github.io/paginate/)

### Note

You just need the "paginate" section of the HTML and the CSS.
The others are just cosmetic helpers for the site.
